import sys
import csv

num_testcases =5
write_first_row, results_file= sys.argv[1:3]

with open(results_file, 'a') as f:
	writer = csv.writer(f)

	if write_first_row=='1':
		row = ['Entry_Number'] 
		row += ['Test'+str(i) for i in range(num_testcases)]
		writer.writerow(row)
	else:
		entrynum, test_results = sys.argv[3:]
		row = [entrynum.upper()]
		cur = 0
		with open(test_results, 'r') as tf:
			for line in tf:
				line = line.strip()
				cur += 1
				row += [line]
			if cur < num_testcases:
				row += [0 for i in range(num_testcases - cur)]
		writer.writerow(row)
