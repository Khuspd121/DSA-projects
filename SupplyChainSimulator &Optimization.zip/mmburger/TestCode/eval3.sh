#!/bin/bash

entrynum_regex="20[0-2][0-9][a-zA-Z0-9]{3}[0-9]{4}"

curwd=$(pwd)

#eval_files="$curwd/*.java"
eval_files="$curwd/A3_TestCases/*"
sub_dir="./submissions"

tester="TestCase"

collectRes="$curwd/collectResults.py"

final_results="$curwd/res.csv"
missing_entrynum="$curwd/missing_entrynum.txt"


local_results="res.txt"

# write first row of CSV file if empty
if ! [ -s "$final_results" ]; then
    python3 $collectRes 1 "$final_results"
fi

cd "$sub_dir"
i=0
for Dp in ./*; do
    if [ -d "$Dp" ]; then
        cd "$Dp"
        echo "$Dp"
        zip_file=$(find . -name "*.zip" -type f)
        echo "$zip_file"
        
        if [[ "$zip_file" =~ $entrynum_regex ]]; then
            entrynum=${BASH_REMATCH[0]} # get entry number from regex match
            echo $entrynum

            # check if entry number already processed
            if grep -iq $entrynum $final_results; then
                cd ..
                continue

            fi

            # unzip submission
            unzip "$zip_file"
        else
            # submitted zip file doesn't contain entry number
            echo "$Dp/$zip_file doesn't contain entry number"
            echo "$Dp/$zip_file" >> $missing_entrynum
            cd ..
            continue
        fi
        # a directory with your entry number as name should be formed
        cd $entrynum

       
        cp $eval_files .

        touch "$local_results"

        echo "Evaluating TestCase0"
        javac -sourcepath . "${tester}0.java" 2> logs.txt
        timeout 300 java "${tester}0" > out.txt 2>> logs.txt
        python3 compare.py "Answer0.txt" "StudentAnswer0.txt" > res.txt 2>comparisonlogs.txt
      
        for i in 1 2 3 4
        do
            echo "Evaluating TestCase${i}"
            javac -sourcepath . "${tester}${i}.java" 2>> logs.txt
            timeout 300 java "${tester}${i}" > out.txt 2>> logs.txt
            python3 compare.py "Answer${i}.txt" "StudentAnswer${i}.txt" >> res.txt 2>>comparisonlogs.txt
        done
        # collect results
        echo "Collecting results"
        python3 $collectRes 0 "$final_results" $entrynum "$local_results" $imports_can_exist 
        echo "Done"
      
        cd ..
        
    	

	
    fi
done
