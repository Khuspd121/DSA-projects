import sys
f1 = sys.argv[1]
f2 = sys.argv[2]

def compare_text_files(f1_name,f2_name):
    f1=""
    try:
        f1 = open(f1_name, "r")
    except:
        print("could not open",f1_name,"returning 0 in compare.py",file=sys.stderr)
        return 0
    f2=""
    try:
        f2 = open(f2_name, "r")
    except:
        print("could not open",f2_name,"returning 0 in compare.py",file=sys.stderr)
        return 0
    # f1 = open(f1_name, "r")
    # f2 = open(f2_name, "r")
    f1_processed = []
    f2_processed = []
    for lines in f1:
        if lines.strip() !='':
            f1_processed.append(lines.strip())
    length=len(f1_processed)
    score=0.0
    minusScore=0
    for lines in f2:
        if lines.strip() != '':
             f2_processed.append(lines.strip())

    for i in range(length):

        # if(len(f1_processed[i])!=1):
            # print(f1_processed[i], "not of length 1", file =sys.stderr)
        try:
            if("--End" in f1_processed[i] or "--Started" in f1_processed[i]):
                #lines with these strings are not considered for scoring
                minusScore+=1
                continue
            if f1_processed[i].lower()== f2_processed[i].lower():
                score+=1
            else:
                #to compare the decimals. atleast 1 decimal place should be correct.
                try:
                    a=int(10*(float(f1_processed[i])))
                    b=int(10*(float(f2_processed[i])))
                    if a==b:
                        score+=1
                except ValueError:
                    pass
        except IndexError:
            break
    return max(0,(score)/(length- minusScore))
try:
    print(f"{compare_text_files(f1,f2):.5f}")
except:
    print("Some error occured while doing compare. Giving 0", file=sys.stderr)
    print(0)