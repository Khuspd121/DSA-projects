public class customer {
    //creates a class called customer and assigns various parameters to it

    int id;
    Queue qassigned;
    int numburgers;
    int burgers;
    int arrivaltime;
    int orderplacedtime;
    int orderstartedtime;
    int orderfinishedtime=Integer.MAX_VALUE;
}
