package Includes;

public class Response {
    public int WaitingTime;
    public boolean Available;
    public int PositionInQueue;     //removable
}
