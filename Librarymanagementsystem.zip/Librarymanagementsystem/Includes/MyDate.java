package Includes;

public class MyDate {
    public int month;
    public int year;
}
