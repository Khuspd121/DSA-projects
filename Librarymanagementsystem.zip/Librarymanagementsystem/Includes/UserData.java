package Includes;

public class UserData {
    public int UserID;
    public int Name;
    public String Address;
    public int Age;
}
